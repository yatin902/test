# MBP Business Process Engine Samples

This project contains several samples created during the evaluation of possible solutions for business process orchestration based on the Business Process Model Notation (BPMN).

The samples comprise:
* `bpmn-engine` as a barebone BPMN 2.0 execution engine for JavaScript (see https://www.npmjs.com/package/bpmn-engine)
* `zeebe` as stand-alone workflow engine for microservices orchestration (see https://zeebe.io/)

To use/explore the samples, run the nest.js in this project by executing `npm i` (once) and `npm start` (to start the server process). The subfolder `postman` contains a Postman collection with sample requests.

## bpmn-engine

The BPMN Engine sample works with the diagram `simple-test.bpmn` from folder `bpmn-diagrams`, which is a simple sequence of service tasks. In `app.service.ts` function `onApplicationBootstrap`, all files from diretory `bpmn-diagrams` are collected and for each diagram a BPMN Engine object is created and stored in memory for later usage. The respective process can then be triggered using the file name without file extension in a POST request to `/bpmn-engine` (see Postman Collection Request "Start bpmn-engine simple process").

The way `bpmn-engine` works is that every service task in the BPMN must be attributed with an implementation like `implementation="${environment.services.confirm}"` pointing to a JavaScript function that must be present in the `services` object in the general execution enviroment context. These JavaScript functions are provided in `app.service.ts` and passed on to the context.

Further process steps with interruptions or asynchronous communication to other parties can be modeled with human/user tasks or messages. Those are implicitly triggered using event listeners similar to the one for starting a process (see e.g. https://github.com/paed01/bpmn-engine/blob/master/docs/Examples.md#user-task). Since `bpmn-engine` does only provide function to get and recover/resume the process instance state (see https://github.com/paed01/bpmn-engine/blob/master/docs/API.md#getstate and https://github.com/paed01/bpmn-engine/blob/master/docs/API.md#recoverstate-recoveroptions), the calling code of the engine must take care of state handling and persistence itself. This was not considered favourable and the evaluation stopped at this point.

## Zeebe

Zeebe has a quite extensive documentation including a "Getting Started Tutorial" available on its docs website: https://docs.zeebe.io/index.html

While the default clients are written for Java and Go, there are many community projects for other languages or frameworks (see https://docs.zeebe.io/clients/other-clients/index.html), including a client for nest.js (https://github.com/pay-k/nestjs-zeebe).


The Zeebe sample has been created with the latter library and based on the tutorial setup available as a predefined Docker Compose definition in https://github.com/zeebe-io/zeebe-docker-compose. Clone this repository and start up the setup with `docker-compose up -d` in its `operate` directory.

If all Docker Containers started successfully, deploy the process from `bpmn-diagrams/two-steps-zeebe.bpmn` to Zeebe by running the following command `./bin/zbctl --insecure deploy <path to two-steps-zeebe.bpmn>` (on MacOS, use the `./bin/zbctl.darwin` command, on Windows `bin/zbctl.exe`). Afterwards, verify that a process with name "Start Contract" is deployed using the operate monitor in the browser running on `http://localhost:8080` (default user credentials `demo` - `demo`).

The Postman Collection contains two requests "Start new Zeebe workflow instance" to start a new instance of the process, and "Trigger Consumer Confirm Message" to trigger sending the message that starts the second part of a process instance. You can find the respective REST controller operations and Zeebe worker implementations in `app.controller.ts`. The sample uses a hard-coded contract DID as the correlation id to identify the process, and prints the current context variables for each step.