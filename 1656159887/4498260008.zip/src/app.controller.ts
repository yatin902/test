import { Controller, Get, Post, Body, Inject } from '@nestjs/common';
import { AppService } from './app.service';
import { ZBClient, CompleteFn } from 'zeebe-node';
import { TriggerProcessDto } from './trigger-process.dto';
import { ZEEBE_CONNECTION_PROVIDER, ZeebeWorker } from '@payk/nestjs-zeebe';
import {
  Ctx,
  Payload,
} from '@nestjs/microservices';
import { ConsumerConfirmDto } from './consumer-confirm.dto';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService,
              @Inject(ZEEBE_CONNECTION_PROVIDER) private readonly zbClient: ZBClient) {}

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  @Post('bpmn-engine')
  triggerProcess(@Body() triggerProcessData: TriggerProcessDto): void {
    this.appService.triggerProcess(triggerProcessData.processId, triggerProcessData.inputData);
  }

  @Post('zeebe')
  triggerProcessZeebe() {
    console.log('creating new workflow instance');
    return this.zbClient.createWorkflowInstance('start-contract', { 
      vehicleDID: 'did:evan:testcore:0x74e2e4fd2f36c43fb0d722cf77e13e18f4ab3c7365e941107ffe7758b7e6dbac',
      signature: '23094adlkfasqß59adkfj'
    });
  }

  @Post('confirm')
  consumerConfirm(@Body() consumerConfirmData: ConsumerConfirmDto) {
    console.log('sending consumer confirm message');
    return this.zbClient.publishMessage({
      name: 'consumer-confirm',
      correlationKey: consumerConfirmData.contractDID,
      timeToLive: 0,
      variables: {
        consumerConfirmSignature: consumerConfirmData.signature
      }
    });
  }

  @ZeebeWorker('validate-claims')
  validateClaims(@Payload() job, @Ctx() complete: CompleteFn<any>) {
      console.log('Validate claims job, Task variables', job.variables);
      let updatedVariables = Object.assign({}, job.variables, {
        valid: true,
      });
      complete.success(updatedVariables);
  }

  @ZeebeWorker('create-contract')
  createContract(@Payload() job, @Ctx() complete: CompleteFn<any>) {
      console.log('Create contract job, Task variables', job.variables);
      let updatedVariables = Object.assign({}, job.variables, {
        contractDID: 'did:evan:testcore:0x74e2e4fd2f36c43fb0d722cf77e13e18f4ab3c7365e941107ffe7758b7e6dbad',
      });
      complete.success(updatedVariables);
  }

  @ZeebeWorker('provider-confirm')
  providerConfirm(@Payload() job, @Ctx() complete: CompleteFn<any>) {
      console.log('Provider confirm job, Task variables', job.variables);
      complete.success();
  }

  @ZeebeWorker('provider-accept')
  providerAccept(@Payload() job, @Ctx() complete: CompleteFn<any>) {
      console.log('Provider accept job, Task variables', job.variables);
      complete.success();
  }
}
