export class TriggerProcessDto {
    processId: string;
    inputData: any;
}