import { Injectable, OnApplicationBootstrap } from '@nestjs/common';
import { readFileSync, readdirSync } from 'fs';
import { Engine } from 'bpmn-engine';
import { EventEmitter } from 'events';

@Injectable()
export class AppService implements OnApplicationBootstrap {

  diagramDirectory = './bpmn-diagrams';

  engines: Map<string, Engine> = new Map();

  services = {
    validate: this.validate,
    changeState(ctx, next) {
      console.log('changeState called', ctx);
      next(null, { state: 'validState' });
    },
    confirm(ctx, next) {
      console.log('confirm called', ctx);
      next();
    },
  };

  getHello(): string {
    return 'Hello BPMN test service!';
  }

  triggerProcess(processId, inputData): void {
    console.log('triggering process with input data ', inputData);
    const listener = new EventEmitter();
    const engine = this.engines.get(processId);
    listener.once('wait', (elementApi) => {
      console.log('wait listener called', elementApi);
      elementApi.signal(inputData);
    });
    engine.execute({
      listener,
      services: this.services
    });
    engine.once('end', (execution) => {
      console.log('process ended');
      console.log(execution.name, execution.environment.output);
    });
    console.log('trigger process end');
  }
  
  onApplicationBootstrap() {
    console.log('Preparing business process engines');
    const diagramFiles = readdirSync(this.diagramDirectory);
    diagramFiles.forEach(diagramFile => {
      console.log('Loading business process from file ' + diagramFile);
      const file = readFileSync(this.diagramDirectory + '/' + diagramFile, 'utf-8');
      const name = diagramFile.substring(0, diagramFile.indexOf('.bpmn'));
      console.log('name: ' + name);
      const engine = Engine({
        name,
        source: file
      });
      this.engines.set(name, engine);
    });
  }

  validate(ctx, next) {
    console.log('validate service called', ctx);
    return next();
  }
}
