export class ConsumerConfirmDto {
    contractDID: string;
    signature: string;
}